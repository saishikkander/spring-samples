package com.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
 
 
public class Hello {
 
	@SuppressWarnings("resource")
	public static void main(String[] args) {
 
		/*// loading the definitions from the given XML file
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
 
		HelloWorldBean service = (HelloWorldBean) context
				.getBean("hello");
		String name = service.getName();
		System.out.println("Hello "+name);
 */
		ApplicationContext c=new ClassPathXmlApplicationContext("applicationContext.xml");
		HelloWorldBean obj1=(HelloWorldBean) c.getBean("hello"); 
		System.out.println("hello"+obj1.getName());
		
		
		
	}
}