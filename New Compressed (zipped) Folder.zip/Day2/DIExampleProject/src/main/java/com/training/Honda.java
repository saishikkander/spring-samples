package com.training;

public class Honda implements CarCompany{
	
public void deliverCar(){
		
		System.out.println("Car delivered by Honda");
	}
	

}
