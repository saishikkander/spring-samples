package com.training;

public class Counter {
	
	int count;
	
	

	public int getCount() {
		return count;
	}



	public void setCount(int count) {
		this.count = count;
	}



	public void incrementCounter(){
		
		++count;
		System.out.println("Count value "+ count );
	}

}
