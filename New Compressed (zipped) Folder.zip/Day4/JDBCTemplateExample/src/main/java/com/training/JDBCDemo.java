package com.training;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class JDBCDemo {
	
	
	
	public static void main(String[] args) {
	      ApplicationContext context = 
	             new ClassPathXmlApplicationContext("applicationContext.xml");

	      StudentJDBCTemplate studentJDBCTemplate = 
	      (StudentJDBCTemplate)context.getBean("studentJDBCTemplate");


	      System.out.println("----Listing Record with ID = 2 -----" );
	      Student student = studentJDBCTemplate.getStudent(2);
	      System.out.print("ID : " + student.getId() );
	      System.out.print(", Name : " + student.getName() );
	      System.out.println(", Age : " + student.getAge());
		  
	
	
	
	}

}