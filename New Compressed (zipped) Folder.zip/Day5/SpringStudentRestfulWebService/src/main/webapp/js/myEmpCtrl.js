var app = angular.module('myApp', []);
app.controller('empCtrl', function($scope, $http) {
	$scope.flag = false;
	$scope.getEmployee = function() {
	    $http.get("http://localhost:8080/SpringStudentRestWebService//student/"+$scope.id)
	    .success(function(response) {$scope.student=response;});
	    $scope.student=null;
	    $scope.flag = true;
	};
	
});